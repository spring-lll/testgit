var express=require('express');
var router=express.Router();
var news=require("../models/backnews");
var http=require("http");
var url=require("url");
var xss=require('xss');

router.get("/delete",function(req,res,next){
    var parameter=url.parse(req.url,true).query;
    var news_=new news({
        newsid:parameter.newsid
    });
    news_.delete(function(err){
        if(err){
            throw err;
        } else{
            res.send(true);
        }
    });
});

router.get("/toUpdate", function (req,res,next) {
    if(req.headers['referer'] = 'http://localhost:8000/home'){
        var parameter=url.parse(req.url,true).query;
        news.get(parameter.newsid,function(err,u,fields){
            if(!u){
                res.send({status:false});
            }else{
                u.newstitle=unescape(u.newstitle);
                u.newsimg=unescape(u.newsimg);
                u.newscontent=unescape(u.newscontent);
                u.adddate=unescape(u.adddate);
                res.send({status:true,news:u});
            }
        });
    }else{
        console.log('The request might be a CSRF-attack');
    }
});

router.post("/update",function(req,res,next){
    var news_=new news({
        newsid:xss(req.body.newsid),
        newstitle:xss(req.body.newstitle),
        newsimg:xss(req.body.newsimg),
        newscontent:xss(req.body.newscontent),
        adddate:xss(req.body.adddate)
    });
    news_.update(function (err) {
        if(err){
            throw err;
        }else{
            res.send(true);
        }
    });
});

router.get('/getList', function(req, res, next){
    var parameter = url.parse(req.url, true).query;
    news.getList(escape(parameter.keyword), function(err, result, fields){
        if (err) {
            result = [];
        }
        for(i=0;i<result.length;i++){
            result[i]['newstitle']=xss(result[i]['newstitle']);
            result[i]['newsimg']=xss(unescape(result[i]['newsimg']));
            result[i]['newscontent']=xss(unescape(result[i]['newscontent']));
            result[i]['adddate']=xss(unescape(result[i]['adddate']));
        }
        res.send({result:result});
    });
});

router.get('/getDetail', function(req, res, next){
    var parameter = url.parse(req.url, true).query;
    news.getList(parameter.newsid, function(err, result, fields){
        if (err) {
            result = [];
        }
        for(i=0;i<result.length;i++){
            result[i]['newstitle']=xss(unescape(result[i]['newstitle']));
            result[i]['newsimg']=xss(unescape(result[i]['newsimg']));
            result[i]['newscontent']=unescape(result[i]['newscontent']);
            result[i]['adddate']=unescape(result[i]['adddate']);
        }
        res.send({result:result,msg:result.newstitle});
    });
});

router.post('/add',function(req,res,next){
    var news_=new  news({
        newstitle:xss(unescape((req.body.newstitle))),
        newsimg:xss(unescape(req.body.newsimg)),
        newscontent:xss(unescape(req.body.newscontent))
        //adddate:req.body.adddate
    });
    if(req.headers['referer'] = 'http://localhost:8000/home'){
        news_.add(function(err,rs,fields){
            if(err){
                console.log("err=="+err);
                res.send({status:false,msg:err});
            } else{
                //console.log(res);
                res.send({status:true,msg:'添加成功'});
            }
        });
    }else{
        console.log('The request might be a CSRF-attack');
    }

});

module.exports=router;