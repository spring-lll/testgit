var express = require('express');
var router = express.Router();
var user=require("../models/user");

/* GET home page. */
router.get('/', function(req, res, next) {
  //res.charset('utf-8');
  res.render('login', { title: '登录首页' });
});

//login
router.get('/login', function (req,res,next) {
  res.render('login',{title: '后台登录页面'});  //注意，登录用的post,不写下面的就会404
});
router.post('/login',function(req,res,next){

  var username_=escape(req.body.username);

    user.get(username_,function(err,user_,fields){
    if(!user_){
      console.log("用户不存在");
      res.send(false);
    }else{
      if(user_.password!=req.body.password){
        console.log("密码错误");
        res.send(false);
      }else{
        req.session.user=user_;
        res.send(true);
      }
    }
  });
});

router.get('/front', function (req,res) {
    res.render('front', { title: '新闻前台' });
});

router.get('/home',function(req,res,next){
 if(!req.session.user){
     res.redirect('/login');
 }else{
     res.render('index',{title: '新闻后台管理系统'});
 }
});

module.exports = router;
