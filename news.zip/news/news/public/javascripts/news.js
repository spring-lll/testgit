function newsAdd(){
    var html = "<ol class='breadcrumb'><li><a href=''>新闻后台管理系统</a></li><li><a href=''>用户管理</a></li><li class='active'>添加新闻</a></li></ol>";
    html+="<div class='table-responsive'><form action='' method='post'>";
    html+="<p><label for='newstitle' class='mar-5'>新闻标题</label><input type='text' name='newstitle' id='newstitle' value='' /></p>";
    html+="<p><label for='newsimg'class='mar-5'>新闻图片</label><input type='text' name='newsimg' id='newsimg' value='' /></p>";
    html+="<p><label for='newscontent'class='mar-5'>新闻内容</label><textarea name='newscontent' rows='' cols='' id='newscontent'></textarea></p>";
    //html+="<p><label for='adddaet'class='mar-5'>添加时间</label><input type='date' name='adddate' id='adddate' value='' /></p>";
    html+="<input type='button' name='submitBtn' id='addSubmit' value='提交'class='btn btn-info mar-5' />";
    html+="<input type='reset' name='resetBtn' id='resetBtn' value='重置' class='btn btn-info'/>";
    html+="</form></div>";
    $("#nw_content").html(html);
}

function newsDel(param){
    var url="newss/delete?newsid="+param;
    $.get(url,function(res){
        if(res){
            alert("删除成功");
            getNewsList('');
        } else{
            alert("哎呀出错了");
        }
    });
}

function newsUpdate(param){
    var url = "newss/toUpdate?newsid="+param;
    $.get(url, function(res){
        if(res.status){
            var html = "<ol class='breadcrumb'><li><a href=''>新闻后台管理系统</a></li><li><a href=''>用户管理</a></li><li class='active'>新闻修改</a></li></ol>";
            html+="<div class='table-responsive'><form action='' method='post'>";
            var data=eval(res.news);
            html+="<p><label for='newsid' class='mar-5'>新闻&nbsp;&nbsp; ID</label><input style='border: 0;' type='text' name='newsid' id='newsid' value="+data.newsid+" readonly/></p>";
            html+="<p><label for='newstitle' class='mar-5'>新闻标题</label><input type='text' id='newstitle' value=' "+data.newstitle+"'/></p>";
            html+="<p><label for='newsimg'class='mar-5'>新闻图片</label><textarea id='newsimg'>"+data.newsimg+" </textarea></p>";
            html+="<p><label for='newscontent'class='mar-5'>新闻内容</label><textarea name='newscontent' rows='' cols='' id='newscontent'>"+data.newscontent+"</textarea></p>";
            html+="<p><label for='adddaet'class='mar-5'>添加时间</label><textarea id='adddate'>"+data.adddate+" </textarea></p>";
            html+="<input type='button' name='updateSubmit' id='updateSubmit' value='提交'class='btn btn-info mar-5' />";
            html+="</form></div>";
            $("#nw_content").html(html);
        }else{
            alert("哎呀出错了");
        }
    });
}

function escapeHtml(string) {
    var entityMap = {
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        '"': '&quot;',
        "'": '&#39;',
        "/": '&#x2F;'
    };
    return String(string).replace(/[&<>"'\/]/g, function (s) {
        return entityMap[s];
    });
}

function getNewsList(keyword){
    $.get("/newss/getList", {keyword: keyword}, function(result){
        var html = "<ol class='breadcrumb'><li><a href=''>新闻后台管理系统</a></li><li><a href=''>用户管理</a></li><li class='active'>首页</a></li></ol>";
        html+="<form method='post'>" +
            "<div class='row head'><div class='col-lg-5 floatr'><div class='input-group'><input name='titleinfo' id='titleinfo' type='text' class='form-control' value=''>";
        html+="<span class='input-group-btn'><input class='btn btn-info' type='button' id='searchSubmit' value='搜索'/><span class='glyphicon glyphicon-search'></span></span></div></div></div></form>";
        html+="<div class='table-responsive'><table class='table table-bordered table-hover'><thead><tr><th style='width: 10%;'>新闻ID</th><th style='width: 15%;'>新闻标题</th><th style='width: 15%;'>新闻图片</th><th style='width: 30%;'>新闻内容</th><th style='width: 15%;'>添加时间</th>><th style='width: 18%;'>操作</th></tr></thead><tbody>";
        var data = eval(result);
        $.each(data.result, function(key, value){
            html+="<tr><td>"+value.newsid+"</td><td>"+escapeHtml(value.newstitle.substr(0,11))+"</td>" +
                "<td>"+escapeHtml(value.newsimg.substr(0,15))+"</td>" +
                "<td>"+escapeHtml(value.newscontent.substr(0,16))+"</td>" +
                "<td>"+escapeHtml(value.adddate.substr(0,15))+"</td>";
            html+="<td><a href=javascript:newsUpdate('"+value.newsid+"') class='floatl mr-10'>修改</a>";
            html+="<a href=javascript:newsDel('"+value.newsid+"') class='floatr mr-10'>删除</a></td></tr>";
            //html+="<a href=javascript:newDetail('"+value.newsid+"') class='mar-5'>查看详情</a></td></tr>";
        });
        html+="</tbody></table></div>"
        $("#nw_content").html(html);
    });
}

$(function(){
    //动态插入的html,需要委派事件处理
    $("#nw_content").delegate("#addSubmit", "click", function(){
        $.post("/newss/add",{
            newstitle: filterXSS($("#newstitle").val()),
            newsimg: $("#newsimg").val(),
            newscontent: $("#newscontent").val(),
            adddate: $("#adddate").val()
        }, function(res){
            alert(res.msg);
            getNewsList('');
        });

    }).delegate("#updateSubmit", "click", function(){
        $.post("/newss/update",{
            newsid:$("#newsid").val(),
            newstitle: $("#newstitle").val(),
            newsimg: $("#newsimg").val(),
            newscontent: $("#newscontent").val(),
            adddate: $("#adddate").val()
        }, function(res){
            if(res){
                getNewsList('');
            }else{
                alert("mjk");
            }
        });

    }).delegate("#searchSubmit", "click", function(){
        var keyword = $("#titleinfo").val();
        getNewsList(keyword);
    });
    getNewsList('');
});
