var client = require("../database");
mysql = client.getDbCon();

function User(user) {
    this.userid = user.userid;
    this.username = user.username;
    this.password = user.password;
}
module.exports = User;

User.get = function(u_name, callback){
    var sql = "select * from user where username='"+u_name+"'";
    mysql.query(sql,function(err, result, fields){
        if(err){
            throw err;
        }else{
            callback(err, result[0], fields);
        }
    });
}


User.getList = function(keyword, callback){
    var sql = "select * from user where 1=1 and username like'%"+keyword+"%'";
    mysql.query(sql, function(err, result, fields){
        if(err){
            throw err;
        }else{
            callback(err, result, fields);
        }
    })
}

User.prototype.add = function add(callback) {
    var user = {
        username: this.username,
        password: this.password
    };
    var sql = "insert into user(username,password) values(?,?)";
    mysql.query(sql, [user.name,user.password], function(err, results, fields){
        if(err){
            throw err;
        }else{
            callback(err, uuid ,fields);
        }
    });
}

User.prototype.update = function(callback) {
    var user = {
        userid:this.userid,
        username: this.username,
        password: this.password
    };

    var sql = "update user set username=?,password=? where userid=?";
    mysql.query(sql, [user.username, user.username, user.userid], function(err, result, fields){
        if(err){
            throw err;
        }
        callback(err);
    });
}


User.prototype.delete = function(callback){
    var user = {
        userid:this.userid
    }
    var sql = "delete from user where userid='"+user.userid+"'";
    mysql.query(sql ,function(err){
        if(err){
            throw err;
        }
        callback(err);
    });
}

