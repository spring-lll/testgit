
var client=require("../database");
var xss=require('xss');
mysql=client.getDbCon();

function News(news){
    this.newsid=news.newsid;
    this.newstitle=news.newstitle;
    this.newsimg=news.newsimg;
    this.newscontent=news.newscontent;
    this.adddate=news.adddate;
    this.source=news.source;
}
module.exports=News;

//查找
News.getList=function(keyword,callback){
    var sql="select * from news where newstitle like '%"+keyword+"%' order by newsid desc";
    mysql.query(sql,function(err,result,fields){
        if(err){
            throw err;
        } else{
            callback(err,result,fields);
        }
    });
}

News.get=function(nw_id,callback){
    var  sql="select * from news where newsid='"+nw_id+"'";
    mysql.query(sql,function(err,result,fields){
        if(err){
            throw err;
        } else{
            callback(err,result[0],fields);
        }
    });
}

//增加
News.prototype.add=function add(callback){
    var news={
        newstitle:unescape(this.newstitle),
        newsimg:unescape(this.newsimg),
        newscontent:unescape(this.newscontent),
        //adddate:this.adddate
    };
    var myDate=new Date();
    var adddate1=myDate.toLocaleTimeString();
    var adddate2=myDate.toLocaleDateString();
    var adddate=adddate2;
    var newsid=this.newsid;
    var sql="insert into news(newstitle,newsimg,newscontent,adddate) values(?,?,?,?)";
    mysql.query(sql,[news.newstitle,news.newsimg,news.newscontent,adddate2],function(err,result,fields){
        if(err){
            throw err;
        } else{
            callback(err,newsid,fields);
        }
    });
}

//更新
News.prototype.update=function(callback){
    var news={
        newsid:this.newsid,
        newstitle:this.newstitle,
        newsimg:this.newsimg,
        newscontent:this.newscontent,
        adddate:this.adddate
    };
    var sql="update news set newstitle=?,newsimg=?,newscontent=?,adddate=? where newsid=?";
    mysql.query(sql,[news.newstitle,news.newsimg,news.newscontent,news.adddate,news.newsid], function (err,result,fields) {
        if(err){
            throw err;
        } else{
            callback(err);
        }
    });
}

//删除
News.prototype.delete=function(callback){
    var news={
        newsid:this.newsid
    };
    var  sql="delete from news where newsid='"+news.newsid+"'";
    mysql.query(sql,function(err){
        if(err){
            throw err;
        } else{
            callback(err);
        }
    });
}