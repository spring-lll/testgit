1. xss防注入：引入了xss模块和escapeHtml（）方法
    在newsss.js的“增加”方法，对所有输入的数据进行了xss的转义。
    在news.js页面(后台)和front.js(前台)，也利用escapeHtml()过滤方法进行了过滤。

2. SQL防注入：对拼接到SQL查询语句中的变量尽量都经过escape过滤函数
    添加的地方：1) index.js--Line 18:  var username_=escape(req.body.username);
    login.js--L8、L9: var username_ = escape($("#username").val());  var passsword_ = escape($("#password").val());
    newss.js-- 对增删改查方法里，用户输入的所有值都进行了escape()验证

3. CSRF防御：在 localhost:8000/home页面下，点击提交会有一个POST到 /newss/toUpdate或/newss/add，
   在newss.js的修改和增加方法下，接收Post后判断referer (newss.js 23、97行)是否来自'http://localhost:8000/home'

4. cookie加入了httpOnly属性，使攻击者无法通过js脚本document.cookie获取cookie信息
   添加地方：app.js---（28行-33行）,同时添加了其他一些属性。
